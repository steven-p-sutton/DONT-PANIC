﻿namespace Microsoft.eShopWeb
{
    public class CatalogSettings
    {
        public string CatalogBaseUrl { get; set; }
    }
}
