﻿namespace BlazorShared.Models
{
    public class CatalogBrand : LookupData
    {
    }
}
