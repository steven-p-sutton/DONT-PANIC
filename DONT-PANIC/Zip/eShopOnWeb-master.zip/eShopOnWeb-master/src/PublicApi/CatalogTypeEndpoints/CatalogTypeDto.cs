﻿namespace Microsoft.eShopWeb.PublicApi.CatalogTypeEndpoints
{
    public class CatalogTypeDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
