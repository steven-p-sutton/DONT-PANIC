﻿using Ardalis.Specification;
using CleanArchitecture.Core.Entities;

namespace CleanArchitecture.Core.Specifications
{
    public class IncompleteItemsSpecification : Specification<ToDoItem>
    {
        public IncompleteItemsSpecification()
        {
            Query.Where(item => !item.IsDone);
        }
    }
}
