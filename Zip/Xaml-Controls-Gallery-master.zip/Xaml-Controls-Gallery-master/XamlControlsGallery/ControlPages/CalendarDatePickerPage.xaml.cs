﻿using Windows.UI.Xaml.Controls;

namespace AppUIBasics.ControlPages
{
    public sealed partial class CalendarDatePickerPage : Page
    {
        public CalendarDatePickerPage()
        {
            this.InitializeComponent();
        }
    }
}
