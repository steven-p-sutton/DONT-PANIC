using Windows.UI.Xaml.Controls;

namespace AppUIBasics.ControlPages
{
    public sealed partial class RatingControlPage : Page
    {
        public RatingControlPage()
        {
            this.InitializeComponent();
        }
    }
}
