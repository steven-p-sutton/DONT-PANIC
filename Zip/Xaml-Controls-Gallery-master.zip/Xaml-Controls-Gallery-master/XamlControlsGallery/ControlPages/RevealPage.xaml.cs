﻿using Windows.UI.Xaml.Controls;

namespace AppUIBasics.ControlPages
{
    public sealed partial class RevealPage : Page
    {
        public RevealPage()
        {
            this.InitializeComponent();
        }
    }
}
