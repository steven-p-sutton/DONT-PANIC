using Windows.UI.Xaml.Controls;

namespace AppUIBasics.SamplePages
{
    public sealed partial class SampleCompactSizingPage : Page
    {
        public SampleCompactSizingPage()
        {
            this.InitializeComponent();
        }
    }
}
