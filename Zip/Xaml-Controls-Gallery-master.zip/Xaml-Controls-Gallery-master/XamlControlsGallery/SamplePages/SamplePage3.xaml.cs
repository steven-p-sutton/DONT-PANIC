using Windows.UI.Xaml.Controls;

namespace AppUIBasics.SamplePages
{
    public sealed partial class SamplePage3 : Page
    {
        public SamplePage3()
        {
            this.InitializeComponent();
        }
    }
}
