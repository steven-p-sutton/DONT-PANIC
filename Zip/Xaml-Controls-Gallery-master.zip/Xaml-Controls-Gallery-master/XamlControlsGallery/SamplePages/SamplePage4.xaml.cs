using Windows.UI.Xaml.Controls;

namespace AppUIBasics.SamplePages
{
    public sealed partial class SamplePage4 : Page
    {
        public SamplePage4()
        {
            this.InitializeComponent();
        }
    }
}
